<?php
// Instagram API details
define('INSTAGRAM_CLIENT_ID', '424988307120533');
define('INSTAGRAM_CLIENT_SECRET', '9c152cfde0086a9bc6c31c9fb9b0db4a');
define('INSTAGRAM_REDIRECT_URI', 'http://localhost/socialsync/api/instagram.php');

// Google Drive API details
define('GOOGLE_CLIENT_ID', '305020745430-c6t6bu7d0ulv2igri1dm3dfc9ah9ifat.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'http://localhost/socialsync/api/google_drive.php');

// Site settings
define('SITE_NAME', 'SocialSync');
define('BASE_URL', 'http://localhost/socialsync/');
?>
