<footer>
        <p>&copy; SocialSync</p>
    </footer>
    <script src="js/scripts.js"></script>
</body>
</html>